import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const ROOT = path.dirname(__filename);

const ignoredFiles = new Set([
  "worker.js",
  "wrangler.json",
  "wrangler.jsonc",
  "generate-files.js",
  "generate-files.mjs",
  "package.json",
  "package-lock.json",
  "files.json",
  ".assetsignore",
  ".gitignore"
]);

const ignoredDirectories = new Set([
  "node_modules",
  ".git"
]);

function scanDirectory(directory, relative = "") {
  const results = [];

  const entries = fs.readdirSync(directory, {
    withFileTypes: true
  });

  for (const entry of entries) {
    const fullPath = path.join(directory, entry.name);
    const relativePath = relative
      ? `${relative}/${entry.name}`
      : entry.name;

    if (entry.isDirectory()) {
      if (ignoredDirectories.has(entry.name)) {
        continue;
      }

      results.push(
        ...scanDirectory(fullPath, relativePath)
      );

      continue;
    }

    if (ignoredFiles.has(entry.name)) {
      continue;
    }

    results.push(relativePath);
  }

  return results;
}

const files = scanDirectory(ROOT).sort(
  (a, b) => a.localeCompare(b)
);

const outputPath = path.join(ROOT, "files.json");

fs.writeFileSync(
  outputPath,
  JSON.stringify(files, null, 2) + "\n",
  "utf8"
);

console.log("Generated files.json:");
console.log(files.join("\n"));