export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/") {
      return showFiles(request, env);
    }

    if (url.pathname === "/download") {
      return downloadFile(request, env);
    }

    return env.ASSETS.fetch(request);
  }
};


async function showFiles(request, env) {
  const manifestURL = new URL("/files.json", request.url);

  const manifestResponse = await env.ASSETS.fetch(
    new Request(manifestURL)
  );

  if (!manifestResponse.ok) {
    return new Response(
      "files.json not found.",
      { status: 500 }
    );
  }

  const files = await manifestResponse.json();

  const rows = files.map(file => {
    const name = file.split("/").pop();

    return `
      <div class="file">

        <div class="info">
          <div class="icon">
            ${getIcon(name)}
          </div>

          <div class="details">
            <div class="name">
              ${escapeHTML(name)}
            </div>

            <div class="path">
              ${escapeHTML(file)}
            </div>
          </div>
        </div>

        <a
          class="download"
          href="/download?file=${encodeURIComponent(file)}"
        >
          Download
        </a>

      </div>
    `;
  }).join("");

  const html = `
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
  name="viewport"
  content="width=device-width, initial-scale=1.0"
>

<title>Downloads</title>

<style>

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  min-height: 100vh;

  padding: 30px 16px;

  font-family:
    -apple-system,
    BlinkMacSystemFont,
    "Segoe UI",
    Roboto,
    Arial,
    sans-serif;

  background:
    linear-gradient(
      135deg,
      #0f172a,
      #111827,
      #1e293b
    );

  color: white;
}

.container {
  max-width: 850px;
  margin: auto;
}

h1 {
  margin: 0;
  font-size: 32px;
}

.subtitle {
  margin: 8px 0 25px;
  color: #94a3b8;
}

.files {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.file {
  display: flex;
  align-items: center;
  justify-content: space-between;

  gap: 15px;

  padding: 16px;

  border-radius: 18px;

  background:
    rgba(255,255,255,.08);

  border:
    1px solid rgba(255,255,255,.10);

  backdrop-filter:
    blur(18px);
}

.info {
  display: flex;
  align-items: center;

  min-width: 0;
  gap: 14px;
}

.icon {
  width: 48px;
  height: 48px;

  flex-shrink: 0;

  display: flex;
  align-items: center;
  justify-content: center;

  border-radius: 14px;

  background:
    rgba(255,255,255,.10);

  font-size: 22px;
}

.details {
  min-width: 0;
}

.name {
  font-weight: 600;

  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.path {
  margin-top: 5px;

  color: #94a3b8;
  font-size: 12px;

  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.download {
  flex-shrink: 0;

  padding: 10px 16px;

  border-radius: 12px;

  background: white;
  color: #111827;

  text-decoration: none;

  font-weight: 600;
  font-size: 14px;
}

.download:hover {
  opacity: .9;
}

@media (max-width: 600px) {

  .file {
    padding: 13px;
  }

  .download {
    padding: 9px 12px;
  }

}

</style>

</head>

<body>

<div class="container">

  <h1>📦 Downloads</h1>

  <div class="subtitle">
    ${files.length} file${files.length === 1 ? "" : "s"} available
  </div>

  <div class="files">
    ${rows}
  </div>

</div>

</body>
</html>
`;

  return new Response(html, {
    headers: {
      "Content-Type": "text/html; charset=UTF-8",
      "Cache-Control": "no-cache"
    }
  });
}


async function downloadFile(request, env) {

  const url = new URL(request.url);

  const file = url.searchParams.get("file");

  if (!file) {
    return new Response(
      "Missing file.",
      { status: 400 }
    );
  }

  // Security protection
  if (
    file.startsWith("/") ||
    file.includes("..") ||
    file.includes("\\")
  ) {
    return new Response(
      "Invalid file.",
      { status: 400 }
    );
  }

  // Load generated manifest
  const manifestURL = new URL(
    "/files.json",
    request.url
  );

  const manifestResponse =
    await env.ASSETS.fetch(
      new Request(manifestURL)
    );

  if (!manifestResponse.ok) {
    return new Response(
      "Manifest unavailable.",
      { status: 500 }
    );
  }

  const files = await manifestResponse.json();

  // Only allow files in the manifest
  if (!files.includes(file)) {
    return new Response(
      "File not found.",
      { status: 404 }
    );
  }

  // Get asset
  const assetURL = new URL(
    "/" + file,
    request.url
  );

  const assetResponse =
    await env.ASSETS.fetch(
      new Request(assetURL)
    );

  if (!assetResponse.ok) {
    return new Response(
      "File not found.",
      { status: 404 }
    );
  }

  const headers =
    new Headers(assetResponse.headers);

  const filename =
    file
      .split("/")
      .pop()
      .replace(/["\\]/g, "");

  headers.set(
    "Content-Disposition",
    `attachment; filename="${filename}"`
  );

  if (
    filename
      .toLowerCase()
      .endsWith(".apk")
  ) {
    headers.set(
      "Content-Type",
      "application/vnd.android.package-archive"
    );
  }

  return new Response(
    assetResponse.body,
    {
      status: 200,
      headers
    }
  );
}


function escapeHTML(value) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}


function getIcon(filename) {

  const name = filename.toLowerCase();

  if (name.endsWith(".apk")) return "📱";
  if (name.endsWith(".pdf")) return "📕";
  if (name.endsWith(".zip")) return "🗜️";

  if (
    name.endsWith(".png") ||
    name.endsWith(".jpg") ||
    name.endsWith(".jpeg") ||
    name.endsWith(".webp")
  ) {
    return "🖼️";
  }

  if (
    name.endsWith(".mp4") ||
    name.endsWith(".webm") ||
    name.endsWith(".mkv")
  ) {
    return "🎬";
  }

  if (
    name.endsWith(".mp3") ||
    name.endsWith(".wav") ||
    name.endsWith(".ogg")
  ) {
    return "🎵";
  }

  return "📄";
}